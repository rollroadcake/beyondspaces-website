<?php
// styles of child theme
function uni_coworking_theme_child_styles() {

    wp_enqueue_style( 'font-awesome-min', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.5.0' );

    $ot_set_google_fonts  = get_theme_mod( 'ot_set_google_fonts', array() );

    if ( !ot_get_option('uni_google_fonts') || empty($ot_set_google_fonts) ) {
        wp_enqueue_style( 'uni-coworking-theme-fonts', uni_coworking_theme_fonts_url(), array(), '1.1.8' );
    }

    wp_enqueue_style( 'bxslider', get_template_directory_uri() . '/css/bxslider.css', array(), '4.2.3' );

    wp_enqueue_style( 'remodal', get_template_directory_uri() . '/css/remodal.css', array(), '1.0.5' );

    wp_enqueue_style( 'remodal-default-theme', get_template_directory_uri() . '/css/remodal-default-theme.css', array(), '1.0.5' );

    wp_enqueue_style( 'ball-clip-rotate', get_template_directory_uri() . '/css/ball-clip-rotate.css', array(), '0.1.0' );

    wp_enqueue_style( 'uni-coworking-theme-styles', get_template_directory_uri() . '/style.css', array('bxslider', 'remodal',
    'remodal-default-theme', 'ball-clip-rotate'), '1.1.8', 'all' );

    wp_enqueue_style( 'uni-coworking-theme-adaptive', get_template_directory_uri() . '/css/adaptive.css', array('uni-coworking-theme-styles'), '1.1.8', 'screen' );

    wp_enqueue_style( 'uni-coworking-theme-child-styles', get_stylesheet_directory_uri() . '/style.css', array( 'uni-coworking-theme-styles' ), '1.1.8', 'screen' );
}
add_action( 'wp_enqueue_scripts', 'uni_coworking_theme_child_styles' );

// after setup of the child theme
add_action( 'after_setup_theme', 'uni_coworking_theme_child_setup' );
function uni_coworking_theme_child_setup() {

    // Enable featured image
    add_theme_support( 'post-thumbnails');

    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );

    // Add html5 suppost for search form and comments list
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

    // translation files for the child theme
    load_child_theme_textdomain( 'coworking-child', get_stylesheet_directory() . '/languages' );
}

// add the new role in the child theme
add_action('after_switch_theme', 'uni_coworking_theme_child_activation_func', 10);
function uni_coworking_theme_child_activation_func() {
}

// remove the new role on theme deactivation
add_action('switch_theme', 'uni_coworking_theme_child_deactivation_func');
function uni_coworking_theme_child_deactivation_func() {
}

function uni_coworking_theme_child_extend_event_meta_box ( $event_meta_box ){
    $category = array(
      'label'       => esc_html__( 'Event category', 'coworking' ),
      'id'          => 'uni_event_category',
      'type'        => 'text',
      'desc'        => esc_html__( 'Please add event category', 'coworking' )
    );
    $link = array(
      'label'       => esc_html__( 'Link to the event page', 'coworking' ),
      'id'          => 'uni_event_link',
      'type'        => 'text',
      'desc'        => esc_html__( 'Please insert link to the event page', 'coworking' )
    );

    array_unshift( $event_meta_box['fields'], $category );
    array_unshift( $event_meta_box['fields'], $link );

	return $event_meta_box;
}
add_filter('unitheme_event_meta_box_array', 'uni_coworking_theme_child_extend_event_meta_box');

function uni_coworking_theme_child_extend_events_meta_box ( $events_meta_box ){
    $category = array(
      'label'       => esc_html__( 'Events category', 'coworking' ),
      'id'          => 'uni_events_category',
      'type'        => 'text',
      'desc'        => esc_html__( 'Please add events category slug name', 'coworking' )
    );

    array_push( $events_meta_box['fields'], $category );

	return $events_meta_box;
}
add_filter('unitheme_events_meta_box_array', 'uni_coworking_theme_child_extend_events_meta_box');

/*
// email templates filter
add_filter( 'uni_coworking_theme_event_email_filter', 'uni_coworking_theme_child_email_templates', 10, 2 );
function uni_coworking_theme_child_email_templates( $sTemplateName, $sState ) {
    if ( $sState == 'guest' ) {
        return '/email/event-custom-guest.php';
    } else if ( $sState == 'admin' ) {
        return '/email/event-custom-admin.php';
    }
}

// switch the subscription email to 'html'
add_filter( 'uni_coworking_theme_mailchimp_variables_filter', 'uni_coworking_theme_mailchimp_variables_func', 10, 1 );
function uni_coworking_theme_mailchimp_variables_func( $aListOfMCVars ) {
    $aListOfMCVars['email_type'] = 'html';
    return $aListOfMCVars;
}
*/
